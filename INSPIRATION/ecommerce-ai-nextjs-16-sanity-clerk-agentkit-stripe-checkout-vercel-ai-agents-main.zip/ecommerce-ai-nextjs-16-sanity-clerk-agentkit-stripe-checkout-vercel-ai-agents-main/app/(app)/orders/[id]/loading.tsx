import { OrderDetailSkeleton } from "@/components/app/OrderDetailSkeleton";

export default function OrderDetailLoading() {
  return <OrderDetailSkeleton />;
}
