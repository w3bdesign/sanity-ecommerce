import { CheckoutSkeleton } from "@/components/app/CheckoutSkeleton";

export default function CheckoutLoading() {
  return <CheckoutSkeleton />;
}
