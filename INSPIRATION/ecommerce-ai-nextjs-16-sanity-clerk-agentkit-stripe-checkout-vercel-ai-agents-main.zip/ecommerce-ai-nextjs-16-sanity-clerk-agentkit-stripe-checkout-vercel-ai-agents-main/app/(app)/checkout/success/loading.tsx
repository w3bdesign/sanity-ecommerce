import { SuccessPageSkeleton } from "@/components/app/SuccessPageSkeleton";

export default function SuccessLoading() {
  return <SuccessPageSkeleton />;
}
